let game = [303, 982, 5, 27, 59, 149, 444, 700, 225, 573];
let choice = Math.floor(Math.random() * 10);
let answer = game[choice];
let myLength = answer.length;
let display = [myLength];
let win = myLength;
let numbers = answer.split('');
let attemptsLeft = answer.length;
let output = '';
let userNum = '';
let found = false;
var numUsed = [];
let numLength = numUsed.length;
let myLength2 = [numLength];

function range(){
        alert(answer);
        for (let i = 0; i < answer.length; i++) {
            display[i] = " ";
            output = output + display[i];
        }
        document.getElementById("range").innerHTML = output;
}
document.getElementById("submit").addEventListener("click", function(event){

    event.preventDefault();
    output = '';
    userNum = document.getElementById("guess").value;
    document.getElementById("guess").value = ''; 
    document.getElementById("guessed").innerHTML = userNum;
    numUsed += numUsed;
    document.getElementById('guesses2').innerHTML = "Guesses: " + numUsed;
    
})
for (let c = 0; c < answer.length; c++){
    let x = 0;
    if (userNum == numbers[c]) {
        display[c] = userNum;
        win--;
        attemptsLeft--;
        found = true;
        if (userNum < (userNum - 50)) or (userNum > (userNum + 50));{
            document.getElementById("guesses").innerHTML = "You are coldest!"
        }
        if (userNum < (userNum - 20)) or (userNum > (userNum + 20));{
            document.getElementById("guesses").innerHTML = "You are cold!"
        }
        if (userNum < (userNum - 10)) or (userNum > (userNum + 10));{
            document.getElementById("guesses").innerHTML = "You are warm!"
        }
        if (userNum < (userNum - 5)) or (userNum > (userNum + 5));{
            document.getElementById("guesses").innerHTML = "You are getting warm!"
        }
        if (userNum < (userNum - 2)) or (userNum > (userNum + 2));{
            document.getElementById("guesses").innerHTML = "You are hot!"
        }
    }
    
    output = output + display[c] + ' ';
}

if (found == false){
    attemptsLeft--;
}

if (win < 1) {
    document.getElementById("guesses").innerHTML = 'You won!';
    document.getElementById("correct").innerHTML = "You guessed the correct answer, " + answer + "!";
} else if (attemptsLeft < 1) {
    document.getElementById("guesses").innerHTML = 'You lost...';
    document.getElementById("correct").innerHTML = "The correct answer was " + answer  + ".";
} else {
    document.getElementById("guesses").innerHTML = 'You have ' + attemptsLeft + ' guesses left';
}

document.getElementById("guesses").innerHTML = output;
output = '';